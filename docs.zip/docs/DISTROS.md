# LinOx 1.0.0 distributions

LinOx downloads native `linux/arm64` userspaces from Docker Hub over HTTPS and stores them in app-private storage. It does not require Android root.

Available catalog:
- Ubuntu 24.04 LTS — `ubuntu:24.04`
- Debian 13 — `debian:13`
- Alpine Linux 3.22 — `alpine:3.22`
- Fedora 42 — `fedora:42`
- Arch Linux — `archlinux:latest`
- Kali Linux Rolling — `kalilinux/kali-rolling:latest`
- Rocky Linux 10 — `rockylinux:10`
- openSUSE Leap — `opensuse/leap:latest`

The manager resolves multi-architecture manifests and selects `linux/arm64`. Downloaded layers are SHA-256 verified. gzip and zstd layers are supported.

Rootfs images are not bundled in the APK; use the distribution manager to download them. This keeps the APK practical while still providing multiple ready-to-install Linux userspaces.
